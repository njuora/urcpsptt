CPLEX: formulation F1 (model1)
CP: formualtion F2 (cp)
GRASP: greedy randimized adaptive search procedure (grasp)
2POH: 2-phase optimization-based heuristic (obh)
Lowerbounds: 
	lower bound based on critcial path method (lb_cp(criticalPath))
	lower bound based on a relaxation of the mTSPSP (lb_mtsp)
		- lb_1tsp records the traveling cost of the first salesperson

In the result files, all activities have been renumbered according to a topological ordering for each instance. The data on the topological orderings is also provided.
